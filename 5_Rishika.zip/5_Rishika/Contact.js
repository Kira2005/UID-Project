import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapLocationDot } from '@fortawesome/free-solid-svg-icons';
import './Contact.css';

function Contact() {
  return (
    
    <div id="contact" className="contact">
      <p className="title">Contact</p>
      <div className="con">
        <h2>Amritapuri Campus</h2>
        <center>
        <p>Amrita Vishwa Vidyapeetham</p>
        <p>Amritapuri, Vallikavu Jn{' '} 
        <a href="https://maps.app.goo.gl/VQx4vQMcuvsRyRre9" target="_blank" rel="noopener noreferrer"> <FontAwesomeIcon icon={faMapLocationDot} className='ico' /> </a> </p>
        <p>Kollam - 686857</p>
        </center>
      </div>
      <br />
    </div>
    
  );
}

export default Contact;
