import React from 'react';
import './Footer.css';

function Footer() {
  return (
    
    <footer>
      <center>
      <p>&copy; Amrita Vishwa Vidyapeetham | 2024</p></center>
    </footer>
  );
}

export default Footer;
