import React from 'react';
import './App.css';
import Header from './Header';
import CourseDetails from './CourseDetails';
import Syllabus from './Syllabus';
import Contact from './Contact';
import Footer from './Footer';


function App() {
  return (
    <div className="content">
      <Header />
      <section id='course'>
      <CourseDetails />
      </section>
      <section id='syllabus'>
      <Syllabus />
      </section>
      <section id='contact'>
      <Contact /></section>
      <Footer />
    </div>
  );
}

export default App;
