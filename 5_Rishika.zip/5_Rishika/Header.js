import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faBook, faDesktop, faPhone } from '@fortawesome/free-solid-svg-icons';
import './Header.css';

function Header() {
  return (
    <header>
      <p className="header-title">
        Computer Hardware Essentials
      </p><br />
      <nav className="nav">
        <span>
          <FontAwesomeIcon icon={faBook} className="icon" />
          <a href="#course" target='_self'>Course Details</a>
        </span>
        <span>
          <FontAwesomeIcon icon={faDesktop} className="icon" />
          <a href="#syllabus" target='_self'>Syllabus</a>
        </span>
        <span>
          <FontAwesomeIcon icon={faPhone} className="icon" />
          <a href="#contact" target='_self'>Contact Us</a>
        </span>
      </nav>
    </header>
  );
}

export default Header;
