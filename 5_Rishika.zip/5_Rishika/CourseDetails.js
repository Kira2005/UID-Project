import React from 'react';
import './CourseDetails.css';

function CourseDetails() {
  return (
    <div id="course">
      <p className="title">Course Details</p>
      <table className="course">
        <tbody>
          <tr>
            <td className="left"><b>Course name:</b></td>
            <td className="right">Computer Hardware Essentials</td>
          </tr>
          <tr>
            <td className="left"><b>Course Code:</b></td>
            <td className="right">23CSE102</td>
          </tr>
          <tr>
            <td className="left"><b>Program:</b></td>
            <td className="right">B.Tech in Computer Science and Engineering, B.Tech in Electronics and Communication Engineering</td>
          </tr>
          <tr>
            <td className="left"><b>Semesters:</b></td>
            <td className="right">One and Two</td>
          </tr>
        </tbody>
      </table>
      <br /><br />
      <p className="subtitle">Course Objectives</p>
      <ul>
        <li>This course is designed to introduce the students to the basics of computing devices, operating systems, installation, configuration, and troubleshooting.</li>
        <li>Elementary concepts of physical computing and Internet of Things are also covered.</li>
      </ul>
    </div>
  );
}

export default CourseDetails;
