import React from 'react';
import './Syllabus.css';

function Syllabus() {
  return (
    
    <div id="syllabus" className="res">
      <p className="title">Syllabus</p>
      <div className="units">
        <h3>Unit 1</h3>
        <p>An overview of the hardware components used to build general purpose and single board computers, mobile phones and laptops, chipsets, interface standards, specifications, and configurations. Installation of operating systems and dual booting.</p>
        <h3>Unit 2</h3>
        <p>Introduction to physical computing, Sensors, actuators, digital and analog I/O ports, communicating over a wired/wireless network.</p>
        <h3>Unit 3</h3>
        <p>Introduction to Raspberry Pi, GPIO Programming, interfacing sensors and actuators. Introduction to IoT, communicating sensor data to cloud platforms.</p>
        <h3>Textbook(s)</h3>
        <p><em>Banzi, Massimo, and Michael Shiloh. "Getting started with Arduino". Maker Media, Inc., 4th edition 2022.</em></p>
        <p><em>Pan, T., Zhu, Y., "Getting Started with Arduino. In: Designing Embedded Systems with Arduino". Springer, Singapore, 2018.</em></p>
        <p><em>Molloy, Derek. "Exploring Raspberry Pi: interfacing to the real world with embedded Linux". John Wiley & Sons, 2016.</em></p>
      </div>
      <div className="eval">
        <p><strong>Evaluation Pattern</strong> 70:30</p>
        <table id="eval">
          <thead>
            <tr>
              <th className="one">Assessment</th>
              <th className="two">Internal</th>
              <th className="three">External</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="one">Midterm</td>
              <td className="two">20</td>
              <td className="three"></td>
            </tr>
            <tr>
              <td className="one">*Continuous Assessment (CA)</td>
              <td className="two">50</td>
              <td className="three"></td>
            </tr>
            <tr>
              <td className="one">**End Semester</td>
              <td className="two"></td>
              <td className="three">30</td>
            </tr>
          </tbody>
        </table>
        <p>*CA - Can be Quizzes/Assignment/Lab Practice</p>
        <p>**End Semester - lab-based examination</p>
      </div>
    </div>
  );
}

export default Syllabus;
