import React from 'react';
import { useForm } from 'react-hook-form';
import './InquiryForm.css'; 

const InquiryForm = ({ onSubmit }) => {
  const { register, handleSubmit, reset } = useForm();

  const handleFormSubmit = (data) => {
    onSubmit(data);
    reset();
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="inquiry-form">
      <h2>Contact Us</h2>
      <label htmlFor="email">Email Address:</label>
      <input type="email" id="email" {...register('email', { required: true })} />
      <label htmlFor="inquiry">Inquiry:</label>
      <textarea id="inquiry" {...register('inquiry', { required: true })} rows={4} />
      <button type="submit">Submit</button>
    </form>
  );
};

export default InquiryForm;
