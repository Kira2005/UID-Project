import React from 'react';

const InquiryList = ({ inquiries }) => (
  <div>
    <h2>Inquiries</h2>
    <ul>
      {inquiries.map((inquiry, index) => (
        <li key={index}>{inquiry}</li>
      ))}
    </ul>
  </div>
);

export default InquiryList;
