import React from 'react';
import './App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBook, faList, faDesktop, faGraduationCap, faEnvelope } from '@fortawesome/free-solid-svg-icons';
import { Link as ScrollLink } from 'react-scroll';

function App() {
  return (
    <div className="App">
      <header>
        <h1>Mathematics Website</h1>
        <NavBar />
      </header>
      <main>
        <DateTime />
        <CourseDetail />
        <Syllabus />
        <Resources />
        <ObjectivesAndOutcomes />
      </main>
      <footer>
        <p>&copy; Amrita Vishwa Vidyapeetham | 2024</p>
      </footer>
    </div>
  );
}

function NavBar() {
  return (
    <nav className="topnav">
      <ScrollLink to="course-detail" smooth={true} duration={500} className="nav-link">
        <FontAwesomeIcon icon={faBook} className="icon" />
        Course Detail
      </ScrollLink>
      <ScrollLink to="syllabus" smooth={true} duration={500} className="nav-link">
        <FontAwesomeIcon icon={faList} className="icon" />
        Syllabus
      </ScrollLink>
      <ScrollLink to="resources" smooth={true} duration={500} className="nav-link">
        <FontAwesomeIcon icon={faDesktop} className="icon" />
        Resources
      </ScrollLink>
      <ScrollLink to="objectives-and-outcomes" smooth={true} duration={500} className="nav-link">
        <FontAwesomeIcon icon={faGraduationCap} className="icon" />
        Objectives and outcomes
      </ScrollLink>
      <a href="InquiryForm.js" target="self" rel="noopener noreferrer" className="nav-link">
        <FontAwesomeIcon icon={faEnvelope} className="icon" />
        Inquiries
      </a>
    </nav>
  );
}

function CourseDetail() {
  return (
    <section id="course-detail" className="content-section">
      <h2>Course Detail</h2>
      <p><strong>Course Name:</strong> Single Variable Calculus</p>
      <p><strong>Code:</strong> 19MAT101</p>
      <p><strong>Program:</strong> B.Tech. in Electrical and Electronics Engineering, B.Tech. in Civil Engineering, B.Tech. in Aerospace Engineering, B.Tech. in Chemical Engineering, B.Tech. in Mechanical Engineering, B.Tech. in Computer Science and Engineering, B.Tech. in Computer and Communication Engineering, B.Tech. in Electronics and Communication Engineering, B.Tech. in Electronics and Computer Engineering</p>
      <p><strong>Semester:</strong> One</p>
    </section>
  );
}

function Syllabus() {
  return (
    <section id="syllabus" className="content-section">
      <h2>Syllabus</h2>
      <h3>Graphs</h3>
      <p>Functions and their Graphs. Shifting and Scaling of Graphs.</p>
      <h3>Limit and Continuity</h3>
      <p>Limit (One Sided and Two Sided) of Functions. Continuous Functions, Discontinuities, Monotonic Functions, Infinite Limits and Limit at Infinity.</p>
      <h3>Graphing</h3>
      <p>Extreme Values of Functions, Concavity and Curve Sketching.</p>
      <h3>Integration</h3>
      <p>Definite Integrals, The Mean Value Theorem for definite integrals, Fundamental Theorem of Calculus, Integration Techniques.</p>
      <h3>Evaluation Pattern</h3>
      <p>Test-1 - 25 marks (one hour test) after 8th lecture. CA – 25 marks (Quizzes / assignments / lab practice) Test – 2- 50 marks (two-hour test) at the end of 15th lecture. Total – 100 marks. Supplementary exam for this course will be conducted as a two-hour test for 100 marks.</p>
    </section>
  );
}

function Resources() {
  return (
    <section id="resources" className="content-section">
      <h2>Resources</h2>
      <ul>
        <li>'Calculus' by G.B. Thomas Pearson Education, 2009, Eleventh Edition.</li>
        <li>'Calculus' by Monty J. Strauss, Gerald J. Bradley</li>
      </ul>
    </section>
  );
}

function ObjectivesAndOutcomes() {
  return (
    <section id="objectives-and-outcomes" className="content-section">
      <h2>Objectives and Outcomes</h2>
      <table>
        <tbody>
          <tr>
            <th>CO1</th>
            <td>To understand the concepts of single variable calculus.</td>
          </tr>
          <tr>
            <th>CO2</th>
            <td>To understand and summarize technical documents.</td>
          </tr>
          <tr>
            <th>CO3</th>
            <td>To sketch graphs for functions using the concepts of single variable calculus and apply the fundamental theorem of calculus to evaluate integrals.</td>
          </tr>
        </tbody>
      </table>
    </section>
  );
}

class DateTime extends React.Component {
  constructor(props) {
    super(props);
    this.state = { date: new Date() };
  }

  componentDidMount() {
    this.timerID = setInterval(() => this.tick(), 1000);
  }

  componentWillUnmount() {
    clearInterval(this.timerID);
  }

  tick() {
    this.setState({ date: new Date() });
  }

  render() {
    return (
      <div id="datetime">
        {this.state.date.toLocaleString()}
      </div>
    );
  }
}

export default App;
