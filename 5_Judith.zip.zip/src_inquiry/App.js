import React from 'react';
import InquiryForm from './components/InquiryForm'; 

function App() {
  const handleSubmit = (data) => {
    console.log('Submitted data:', data);

  };

  return (
    <div className="App">
      <InquiryForm onSubmit={handleSubmit} />
    </div>
  );
}

export default App;
