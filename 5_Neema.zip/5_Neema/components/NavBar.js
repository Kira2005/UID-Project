import React from 'react';
import './NavBar.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faBook, faGraduationCap, faMobile } from '@fortawesome/free-solid-svg-icons';


const NavBar = () => (
  <nav>
    <ul>
      <li><FontAwesomeIcon icon={faHome} style={{color: "#0a0a0b",}} /><a href="#Home" className="nav-link">Home</a></li>
      <li><FontAwesomeIcon icon={faBook} style={{color: "#19191a",}} /><a href="#CourseDetails" className="nav-link">Course Details</a></li>
      <li><FontAwesomeIcon icon={faGraduationCap} style={{color: "#0f0f10",}} /><a href="#Resources" className="nav-link">Resources</a></li>
      <li><FontAwesomeIcon icon={faMobile} style={{color: "#161717",}} /><a href="#Contact" className="nav-link">Contact</a></li>
    </ul>
  </nav>
);

export default NavBar;
