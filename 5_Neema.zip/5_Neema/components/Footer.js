import React from 'react';
import './Footer.css';

const Footer = () => (
  <footer>
    <p>&copy; Amrita Vishwa Vidyapeetham | 2024</p>
  </footer>
);

export default Footer;
