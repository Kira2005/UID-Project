import React, { useState } from 'react';
import './CourseDetails.css';

const CourseDetails = () => {
  const [activeUnits, setActiveUnits] = useState([false, false, false, false]);

  const toggleUnit = (index) => {
    setActiveUnits(prevState => {
      const newActiveUnits = [...prevState];
      newActiveUnits[index] = !newActiveUnits[index];
      return newActiveUnits;
    });
  };

  return (
    <div className="details">
      <h1 id="CourseDetails"><center>Course Details</center></h1>
      <center>
        <div className="unit-block">
          <h3>Course Objective</h3>
          <p>The main objective of the course is to expose to the development of Physics with special emphasis on Quantum mechanics-which enable a computer science engineer to apply this in the field of emerging areas like quantum computing.</p>
        </div>
      </center>
      <div className="units-container">
        {[1, 2, 3, 4].map((unit, index) => (
          <div
            key={unit}
            className="unit-block"
            onClick={() => toggleUnit(index)}
          >
            <p><strong>Unit {unit}</strong></p>
            <div className={`unit-content ${activeUnits[index] ? 'active' : ''}`}>
              <p>{getUnitContent(unit)}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const getUnitContent = (unit) => {
  const contents = {
    1: 'Origin of quantum theory of radiation: Black body radiation, photo-electric effect, Compton Effect - pair production and annihilation, De-Broglie hypothesis, description of waves and wave packets, group velocities. Evidence for wave nature of particles: Davisson-Germer experiment, Heisenberg uncertainty principle.',
    2: "Atomic structure: Historical Development of atomic structures: Thomson's Model, Rutherford's Model: Scattering formula and its predictions, Atomic spectra - Bohr's Model, Sommerfield's Model, The correspondence principle, nuclear motion, and atomic excitation, Application: Lasers.",
    3: "Quantum mechanics: Wave function, Probability density, expectation values - Schrodinger equation - time dependent and independent, Linearity and superposition, expectation values, operators, Eigen functions and Eigen values",
    4: "Application of 1D Schrodinger Wave equation: Free particle, Particle in a box, Finite potential well, Tunnel effect, Harmonic oscillator.",
  };
  return contents[unit];
};

export default CourseDetails;
