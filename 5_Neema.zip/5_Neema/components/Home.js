import React from 'react';
import './Home.css';

const Home = () => (
  <div className="container">
    <h1 id="Home">Home</h1>
    <aside><img src="https://cdn.kobo.com/book-images/3587e500-5349-4485-b992-31da9885777c/1200/1200/False/modern-physics-1.jpg" alt="Modern Physics" /></aside>
    <p>Modern physics is a branch of physics that developed in the early 20th century 
        and onward or branches greatly influenced by early 20th century physics. 
        Notable branches of modern physics include quantum mechanics, special relativity
         and general relativity.</p>
        
        <p>Classical physics is typically concerned with everyday conditions: speeds are much lower than the speed of light, sizes are much greater than that of atoms, and energies are relatively small. Modern physics, however, is concerned with more extreme conditions,such as high velocities that are comparable to the speed of light (special relativity),small distances comparable to the tomic radius (quantum mechanics), and very high energies(relativity). In general, quantum and relativistic effects are believed to exist across all scales, although these effects may be very small at human scale. While quantum mechanics is compatible with special relativity (See: Relativistic quantum mechanics), one of the unsolved problems in physics is the unification of quantum mechanics and general relativity, which the Standard Model of particle physics currently cannot account for.</p>
          
        <p>Modern physics is an effort to understand the underlying processes of the interactions of 
        matter using the tools of science & engineering. In a literal sense, the term modern physics 
        means up-to-date physics. In this sense, a significant portion of so-called classical physics 
        is modern. However, since roughly 1890, new discoveries have caused significant paradigm 
        shifts: especially the advent of quantum mechanics (QM) and relativity (ER). Physics that 
        incorporates elements of either QM or ER (or both) is said to be modern physics. It is in this 
        latter sense that the term is generally used.</p>
  </div>
);

export default Home;
