import React, { useState } from 'react';
import './Resources.css';

const Resources = () => {
  const [search, setSearch] = useState('');

  const handleSearch = (event) => {
    setSearch(event.target.value.toLowerCase());
  };

  const references = [
    'Arthur Beiser, Shobhit Mahajan, S Raj Choudhury, "Concepts of Physics"',
    'Eleanor G. Rieffel and Wolfgang H. Polak, "Quantum Computing, A Gentle Introduction"',
    'R Shankar, "Principles of Quantum Mechanics"',
    'LI Schiff, "Quantum Mechanics"',
  ];

  return (
    <div classname="break">
     

    <div className="container3">
      
      <h1 className="resources-title">Resources</h1>
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search resources..."
          onChange={handleSearch}
        />
      </div>
      <table id="resources-table">
        <tbody>
          {references
            .filter((ref) => ref.toLowerCase().includes(search))
            .map((ref, index) => (
              <tr key={index}>
                <td>{ref}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
    </div>
  );
};

export default Resources;
