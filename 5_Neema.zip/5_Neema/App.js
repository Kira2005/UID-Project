import React from 'react';
import Header from './components/Header';
import NavBar from './components/NavBar';
import Home from './components/Home';
import CourseDetails from './components/CourseDetails';
import Resources from './components/Resources';
import Contact from './components/Contact';
import Footer from './components/Footer';
import './App.css';

function App() {
  return (
    <div className="App">
      <Header />
      <NavBar />
      <div id="Home" className="section">
      <Home />
      </div>
      <div id="CourseDetails" className="section">
        <CourseDetails />
      </div>
      
      <div id="Resources" className="section">
      <Resources />
      </div>
      
      <div id="Contact" className="section">
      <Contact />
      </div>
      
      <Footer />
    </div>
  );
}

export default App;
